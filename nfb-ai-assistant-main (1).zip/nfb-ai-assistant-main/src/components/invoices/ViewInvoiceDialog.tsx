import { Invoice } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Download, Printer } from 'lucide-react';

interface ViewInvoiceDialogProps {
  invoice: Invoice | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const statusStyles = {
  paid: 'bg-success/10 text-success border-success/20',
  sent: 'bg-accent/10 text-accent border-accent/20',
  draft: 'bg-muted text-muted-foreground border-muted',
  overdue: 'bg-destructive/10 text-destructive border-destructive/20',
};

export function ViewInvoiceDialog({ invoice, open, onOpenChange }: ViewInvoiceDialogProps) {
  if (!invoice) return null;

  const isNFBTemplate = invoice.template === 'nfb-trading';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Invoice {invoice.invoiceNumber}</span>
            <Badge variant="outline" className={cn('capitalize', statusStyles[invoice.status])}>
              {invoice.status}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {/* Invoice Preview */}
        <div className="bg-white text-black rounded-lg p-8 space-y-6">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold text-primary">
                {isNFBTemplate ? 'NFB TRADING LTD' : 'TELETEK TECHNAHH BV'}
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                {isNFBTemplate ? 'Sales Invoice' : 'Invoice'}
              </p>
            </div>
            <div className="text-right text-sm">
              <p><span className="font-medium">Invoice No:</span> {invoice.invoiceNumber}</p>
              <p><span className="font-medium">Date:</span> {format(invoice.createdAt, 'dd/MM/yyyy')}</p>
              <p><span className="font-medium">Due Date:</span> {format(invoice.dueDate, 'dd/MM/yyyy')}</p>
            </div>
          </div>

          <Separator className="bg-gray-200" />

          {/* Client Info */}
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-sm text-gray-500 uppercase mb-2">Bill To</h3>
              <p className="font-medium">{invoice.customer?.name || 'Unknown Customer'}</p>
              <p className="text-sm text-gray-600">{invoice.customer?.email}</p>
              {invoice.customer?.phone && <p className="text-sm text-gray-600">{invoice.customer.phone}</p>}
              {invoice.billingAddress && <p className="text-sm text-gray-600 mt-1">{invoice.billingAddress}</p>}
            </div>
            {invoice.shippingAddress && (
              <div>
                <h3 className="font-semibold text-sm text-gray-500 uppercase mb-2">Ship To</h3>
                <p className="text-sm text-gray-600">{invoice.shippingAddress}</p>
              </div>
            )}
          </div>

          {/* Items Table */}
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-4 font-medium text-gray-600">Description</th>
                  <th className="text-center py-3 px-4 font-medium text-gray-600">Qty</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-600">Unit Price</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-600">Total</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item, index) => (
                  <tr key={index} className="border-t border-gray-200">
                    <td className="py-3 px-4">
                      <p className="font-medium">{item.productName}</p>
                      <p className="text-gray-500 text-xs">{item.specs} - {item.color}</p>
                    </td>
                    <td className="py-3 px-4 text-center">{item.quantity}</td>
                    <td className="py-3 px-4 text-right">€{item.unitPrice.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right font-medium">€{item.lineTotal.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span>€{invoice.subtotal.toLocaleString()}</span>
              </div>
              {invoice.tax > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span>€{invoice.tax.toLocaleString()}</span>
                </div>
              )}
              {invoice.shipping > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span>€{invoice.shipping.toLocaleString()}</span>
                </div>
              )}
              <Separator className="bg-gray-200" />
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>€{invoice.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Footer Note */}
          {!isNFBTemplate && (
            <div className="pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-500 text-center">
                GOODS ARE SOLD UNDER MARGINAL VAT SCHEME
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" size="sm">
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button size="sm" className="btn-accent-gradient">
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
