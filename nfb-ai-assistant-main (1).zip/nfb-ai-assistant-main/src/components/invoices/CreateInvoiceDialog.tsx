import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Invoice, InvoiceItem } from '@/types';
import { useProducts } from '@/hooks/useProducts';
import { useSellers } from '@/hooks/useSellers';
import { useCustomers } from '@/hooks/useCustomers';
import { FileText, Plus, Trash2 } from 'lucide-react';

interface CreateInvoiceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreate: (invoice: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt'>) => void;
}

export function CreateInvoiceDialog({ open, onOpenChange, onCreate }: CreateInvoiceDialogProps) {
  const { products } = useProducts();
  const { sellers } = useSellers();
  const { customers } = useCustomers();
  
  const [template, setTemplate] = useState<'nfb-trading' | 'teletek'>('nfb-trading');
  const [sellerId, setSellerId] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [billingAddress, setBillingAddress] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState('1');

  // Auto-fill billing address when customer is selected
  const handleCustomerChange = (id: string) => {
    setCustomerId(id);
    const customer = customers.find(c => c.id === id);
    if (customer?.billingAddress) {
      setBillingAddress(customer.billingAddress);
    }
  };

  const addItem = () => {
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    const qty = parseInt(quantity) || 1;
    const newItem: InvoiceItem = {
      productId: product.id,
      productName: product.name,
      specs: product.specs,
      color: product.color,
      quantity: qty,
      unitPrice: product.unitPrice,
      lineTotal: product.unitPrice * qty,
    };

    setItems([...items, newItem]);
    setSelectedProductId('');
    setQuantity('1');
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
  const total = subtotal;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedSeller = sellers.find(s => s.id === sellerId);
    const selectedCustomer = customers.find(c => c.id === customerId);
    
    onCreate({
      template,
      sellerId,
      seller: selectedSeller,
      customerId,
      customer: selectedCustomer,
      billingAddress,
      items,
      subtotal,
      tax: 0,
      shipping: 0,
      total,
      status: 'draft',
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    });

    // Reset form
    setSellerId('');
    setCustomerId('');
    setBillingAddress('');
    setItems([]);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-accent" />
            </div>
            <div>
              <DialogTitle>Create New Invoice</DialogTitle>
              <DialogDescription>
                Create a professional invoice for your client
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Template Selection */}
          <div>
            <Label>Invoice Template</Label>
            <div className="grid grid-cols-2 gap-3 mt-2">
              <button
                type="button"
                onClick={() => setTemplate('nfb-trading')}
                className={`p-4 rounded-xl border-2 transition-all text-left ${
                  template === 'nfb-trading' 
                    ? 'border-accent bg-accent/5' 
                    : 'border-border hover:border-accent/50'
                }`}
              >
                <p className="font-semibold">NFB Trading LTD</p>
                <p className="text-xs text-muted-foreground mt-1">Professional sales invoice format</p>
              </button>
              <button
                type="button"
                onClick={() => setTemplate('teletek')}
                className={`p-4 rounded-xl border-2 transition-all text-left ${
                  template === 'teletek' 
                    ? 'border-accent bg-accent/5' 
                    : 'border-border hover:border-accent/50'
                }`}
              >
                <p className="font-semibold">TELETEK TECHNAHH BV</p>
                <p className="text-xs text-muted-foreground mt-1">Marginal VAT scheme format</p>
              </button>
            </div>
          </div>

          {/* Seller & Customer Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="seller">Seller</Label>
              <Select value={sellerId} onValueChange={setSellerId}>
                <SelectTrigger className="mt-1.5 input-focus">
                  <SelectValue placeholder="Select seller" />
                </SelectTrigger>
                <SelectContent>
                  {sellers.map((seller) => (
                    <SelectItem key={seller.id} value={seller.id}>
                      {seller.companyName || seller.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="customer">Customer</Label>
              <Select value={customerId} onValueChange={handleCustomerChange}>
                <SelectTrigger className="mt-1.5 input-focus">
                  <SelectValue placeholder="Select customer" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} {customer.email ? `(${customer.email})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label htmlFor="billingAddress">Billing Address</Label>
              <Textarea
                id="billingAddress"
                value={billingAddress}
                onChange={(e) => setBillingAddress(e.target.value)}
                placeholder="123 Business Street, London, UK"
                className="mt-1.5 input-focus min-h-[80px]"
                required
              />
            </div>
          </div>

          {/* Add Items */}
          <div>
            <Label>Invoice Items</Label>
            <div className="flex gap-2 mt-2">
              <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                <SelectTrigger className="flex-1 input-focus">
                  <SelectValue placeholder="Select product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name} - {product.color} (€{product.unitPrice})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-20 input-focus"
                placeholder="Qty"
              />
              <Button 
                type="button" 
                variant="outline" 
                onClick={addItem}
                disabled={!selectedProductId}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {/* Items List */}
            {items.length > 0 && (
              <div className="mt-4 rounded-lg border border-border overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="text-left p-3 font-medium">Product</th>
                      <th className="text-right p-3 font-medium">Qty</th>
                      <th className="text-right p-3 font-medium">Price</th>
                      <th className="text-right p-3 font-medium">Total</th>
                      <th className="p-3"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, index) => (
                      <tr key={index} className="border-t border-border">
                        <td className="p-3">
                          <p className="font-medium">{item.productName}</p>
                          <p className="text-xs text-muted-foreground">{item.color}</p>
                        </td>
                        <td className="p-3 text-right">{item.quantity}</td>
                        <td className="p-3 text-right">€{item.unitPrice.toLocaleString()}</td>
                        <td className="p-3 text-right font-medium">€{item.lineTotal.toLocaleString()}</td>
                        <td className="p-3">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            onClick={() => removeItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-muted/30">
                    <tr className="border-t border-border">
                      <td colSpan={3} className="p-3 text-right font-semibold">Total:</td>
                      <td className="p-3 text-right font-bold text-lg">€{total.toLocaleString()}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="btn-accent-gradient" disabled={items.length === 0}>
              Create Invoice
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
