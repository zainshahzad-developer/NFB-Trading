import { useState } from 'react';
import { Invoice } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Plus, 
  Eye, 
  Download,
  FileText,
  Filter,
  MoreVertical
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { CreateInvoiceDialog } from './CreateInvoiceDialog';
import { ViewInvoiceDialog } from './ViewInvoiceDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const statusStyles = {
  paid: 'bg-success/10 text-success border-success/20',
  sent: 'bg-accent/10 text-accent border-accent/20',
  draft: 'bg-muted text-muted-foreground border-muted',
  overdue: 'bg-destructive/10 text-destructive border-destructive/20',
};

// Mock data for now - will be replaced with database later
const mockInvoices: Invoice[] = [
  {
    id: '1',
    invoiceNumber: 'INV-2024-001',
    template: 'nfb-trading',
    billingAddress: '123 Business Street, London, UK',
    customer: { id: '1', name: 'Mark Johnson', email: 'mark@company.com', phone: '+44 20 7123 4567', createdAt: new Date(), updatedAt: new Date() },
    items: [
      { productId: '1', productName: 'iPhone 15 Pro Max', specs: '256GB, A17 Pro chip', color: 'Natural Titanium', quantity: 5, unitPrice: 1199, lineTotal: 5995 },
    ],
    subtotal: 5995,
    tax: 0,
    shipping: 0,
    total: 5995,
    status: 'paid',
    dueDate: new Date('2024-02-15'),
    createdAt: new Date('2024-01-20'),
    paidAt: new Date('2024-01-25'),
  },
  {
    id: '2',
    invoiceNumber: 'INV-2024-002',
    template: 'teletek',
    billingAddress: '456 Tech Avenue, Amsterdam, NL',
    customer: { id: '2', name: 'Sarah Williams', email: 'sarah@techcorp.com', createdAt: new Date(), updatedAt: new Date() },
    items: [
      { productId: '5', productName: 'Samsung Galaxy S24 Ultra', specs: '256GB, Snapdragon 8 Gen 3', color: 'Titanium Black', quantity: 10, unitPrice: 1299, lineTotal: 12990 },
      { productId: '6', productName: 'Google Pixel 8 Pro', specs: '128GB, Tensor G3', color: 'Obsidian', quantity: 5, unitPrice: 999, lineTotal: 4995 },
    ],
    subtotal: 17985,
    tax: 0,
    shipping: 50,
    total: 18035,
    status: 'sent',
    dueDate: new Date('2024-02-28'),
    createdAt: new Date('2024-01-28'),
  },
  {
    id: '3',
    invoiceNumber: 'INV-2024-003',
    template: 'nfb-trading',
    billingAddress: '789 Commerce Road, Berlin, DE',
    customer: { id: '3', name: 'David Chen', email: 'david@electronics.com', createdAt: new Date(), updatedAt: new Date() },
    items: [
      { productId: '7', productName: 'MacBook Pro 16"', specs: 'M3 Max, 36GB RAM, 1TB SSD', color: 'Space Black', quantity: 3, unitPrice: 2499, lineTotal: 7497 },
    ],
    subtotal: 7497,
    tax: 0,
    shipping: 0,
    total: 7497,
    status: 'overdue',
    dueDate: new Date('2024-01-15'),
    createdAt: new Date('2024-01-01'),
  },
];

export function InvoiceList() {
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const filteredInvoices = invoices.filter(invoice =>
    invoice.customer?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateInvoice = (invoice: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt'>) => {
    const newInvoice: Invoice = {
      ...invoice,
      id: (invoices.length + 1).toString(),
      invoiceNumber: `INV-2024-${String(invoices.length + 1).padStart(3, '0')}`,
      createdAt: new Date(),
    };
    setInvoices([newInvoice, ...invoices]);
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Invoices', value: invoices.length, color: 'text-foreground' },
          { label: 'Paid', value: invoices.filter(i => i.status === 'paid').length, color: 'text-success' },
          { label: 'Pending', value: invoices.filter(i => i.status === 'sent').length, color: 'text-accent' },
          { label: 'Overdue', value: invoices.filter(i => i.status === 'overdue').length, color: 'text-destructive' },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl bg-card p-4 border border-border">
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className={cn('text-2xl font-bold', stat.color)}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search invoices..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 input-focus"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button onClick={() => setIsCreateDialogOpen(true)} className="btn-accent-gradient">
            <Plus className="h-4 w-4 mr-2" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* Invoice Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredInvoices.map((invoice) => (
          <div
            key={invoice.id}
            className="rounded-xl bg-card border border-border p-5 shadow-card transition-all duration-200 hover:shadow-lg hover:border-accent/30"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-card-foreground">{invoice.invoiceNumber}</p>
                  <p className="text-xs text-muted-foreground capitalize">{invoice.template} template</p>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => {
                    setSelectedInvoice(invoice);
                    setIsViewDialogOpen(true);
                  }}>
                    <Eye className="h-4 w-4 mr-2" />
                    View
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Download className="h-4 w-4 mr-2" />
                    Download PDF
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-card-foreground">{invoice.customer?.name || 'Unknown Customer'}</p>
                <p className="text-xs text-muted-foreground">{invoice.customer?.email}</p>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="text-lg font-bold text-card-foreground">
                    €{invoice.total.toLocaleString()}
                  </p>
                </div>
                <Badge variant="outline" className={cn('capitalize', statusStyles[invoice.status])}>
                  {invoice.status}
                </Badge>
              </div>

              <div className="pt-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                <span>Created: {format(invoice.createdAt, 'MMM d, yyyy')}</span>
                <span>Due: {format(invoice.dueDate, 'MMM d, yyyy')}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create Invoice Dialog */}
      <CreateInvoiceDialog
        open={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        onCreate={handleCreateInvoice}
      />

      {/* View Invoice Dialog */}
      <ViewInvoiceDialog
        invoice={selectedInvoice}
        open={isViewDialogOpen}
        onOpenChange={setIsViewDialogOpen}
      />
    </div>
  );
}
