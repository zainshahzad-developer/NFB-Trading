import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { SalesChart } from '@/components/dashboard/SalesChart';
import { RecentInvoices } from '@/components/dashboard/RecentInvoices';
import { LowStockAlert } from '@/components/dashboard/LowStockAlert';
import { useProducts } from '@/hooks/useProducts';
import { Package, AlertTriangle, DollarSign, ShoppingCart } from 'lucide-react';

export default function Index() {
  const { products, loading } = useProducts();
  const lowStockItems = products.filter(p => p.quantity <= p.minStock).length;

  return (
    <MainLayout title="Dashboard" subtitle="Welcome back! Here's what's happening with your business.">
      <div className="space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Products" value={loading ? '-' : products.length} icon={Package} iconColor="text-accent" iconBg="bg-accent/10" />
          <StatCard title="Total Revenue" value="€0" icon={DollarSign} iconColor="text-success" iconBg="bg-success/10" />
          <StatCard title="Today's Sales" value="€0" icon={ShoppingCart} iconColor="text-primary" iconBg="bg-primary/10" />
          <StatCard title="Low Stock Items" value={loading ? '-' : lowStockItems} icon={AlertTriangle} iconColor="text-warning" iconBg="bg-warning/10" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2"><SalesChart /></div>
          <div><LowStockAlert /></div>
        </div>
        <RecentInvoices />
      </div>
    </MainLayout>
  );
}
