import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, TrendingUp, Download, DollarSign, Package, FileText, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const revenueData = [
  { name: 'Week 1', revenue: 12400 },
  { name: 'Week 2', revenue: 15600 },
  { name: 'Week 3', revenue: 18900 },
  { name: 'Week 4', revenue: 21200 },
];

const productsByCategory = [
  { category: 'Smartphones', count: 85 },
  { category: 'Laptops', count: 32 },
  { category: 'Tablets', count: 18 },
  { category: 'Accessories', count: 45 },
];

const COLORS = ['hsl(173, 58%, 39%)', 'hsl(222, 47%, 20%)', 'hsl(38, 92%, 50%)', 'hsl(215, 20%, 65%)'];

export default function Reports() {
  return (
    <MainLayout title="Reports & Analytics" subtitle="Track your business performance and insights">
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: 'This Month Revenue', value: '€67,890', icon: DollarSign, change: '+15.3%' },
            { title: 'Total Orders', value: '156', icon: FileText, change: '+8.2%' },
            { title: 'Products Sold', value: '423', icon: Package, change: '+12.5%' },
            { title: 'Active Customers', value: '89', icon: Users, change: '+5.1%' },
          ].map((stat) => (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold mt-1">{stat.value}</p>
                    <p className="text-sm text-success mt-1">{stat.change}</p>
                  </div>
                  <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center">
                    <stat.icon className="h-6 w-6 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div><CardTitle>Weekly Revenue</CardTitle><CardDescription>Revenue breakdown by week</CardDescription></div>
              <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" />Export</Button>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 32%, 91%)" />
                    <XAxis dataKey="name" stroke="hsl(215, 16%, 47%)" fontSize={12} />
                    <YAxis stroke="hsl(215, 16%, 47%)" fontSize={12} tickFormatter={(v) => `€${v/1000}k`} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(0, 0%, 100%)', border: '1px solid hsl(214, 32%, 91%)', borderRadius: '8px' }} formatter={(value: number) => [`€${value.toLocaleString()}`, 'Revenue']} />
                    <Bar dataKey="revenue" fill="hsl(173, 58%, 39%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Products by Category</CardTitle><CardDescription>Inventory distribution</CardDescription></CardHeader>
            <CardContent>
              <div className="h-[300px] flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={productsByCategory} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="count" label={({ category, count }) => `${category}: ${count}`} labelLine={false}>
                      {productsByCategory.map((_, index) => (<Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-4 mt-4">
                {productsByCategory.map((entry, index) => (
                  <div key={entry.category} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                    <span className="text-sm text-muted-foreground">{entry.category}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        <Card>
          <CardHeader><CardTitle>Generate Reports</CardTitle><CardDescription>Export detailed reports for your records</CardDescription></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { title: 'Sales Report', description: 'Complete sales summary', icon: TrendingUp },
                { title: 'Inventory Report', description: 'Stock levels & values', icon: Package },
                { title: 'Invoice Report', description: 'All invoices & status', icon: FileText },
                { title: 'Custom Report', description: 'Build your own report', icon: BarChart3 },
              ].map((report) => (
                <button key={report.title} className="p-4 rounded-xl border border-border hover:border-accent/50 hover:bg-accent/5 transition-all text-left group">
                  <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center mb-3 group-hover:bg-accent/10 transition-colors">
                    <report.icon className="h-5 w-5 text-muted-foreground group-hover:text-accent transition-colors" />
                  </div>
                  <p className="font-medium">{report.title}</p>
                  <p className="text-sm text-muted-foreground">{report.description}</p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
