import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Product } from '@/types';
import { toast } from 'sonner';

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setProducts(data.map(p => ({
        id: p.id,
        name: p.name,
        specs: p.specs,
        color: p.color,
        quantity: p.quantity,
        unitPrice: Number(p.unit_price),
        minStock: p.min_stock,
        category: p.category,
        createdAt: new Date(p.created_at),
        updatedAt: new Date(p.updated_at),
      })));
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const { data, error } = await supabase
        .from('products')
        .insert({
          name: product.name,
          specs: product.specs,
          color: product.color,
          quantity: product.quantity,
          unit_price: product.unitPrice,
          min_stock: product.minStock,
          category: product.category,
        })
        .select()
        .single();

      if (error) throw error;

      setProducts(prev => [{
        id: data.id,
        name: data.name,
        specs: data.specs,
        color: data.color,
        quantity: data.quantity,
        unitPrice: Number(data.unit_price),
        minStock: data.min_stock,
        category: data.category,
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at),
      }, ...prev]);

      toast.success('Product added successfully');
      return data;
    } catch (error) {
      console.error('Error adding product:', error);
      toast.error('Failed to add product');
      throw error;
    }
  };

  const updateProduct = async (id: string, updates: Partial<Omit<Product, 'id' | 'createdAt' | 'updatedAt'>>) => {
    try {
      const dbUpdates: Record<string, unknown> = {};
      if (updates.name !== undefined) dbUpdates.name = updates.name;
      if (updates.specs !== undefined) dbUpdates.specs = updates.specs;
      if (updates.color !== undefined) dbUpdates.color = updates.color;
      if (updates.quantity !== undefined) dbUpdates.quantity = updates.quantity;
      if (updates.unitPrice !== undefined) dbUpdates.unit_price = updates.unitPrice;
      if (updates.minStock !== undefined) dbUpdates.min_stock = updates.minStock;
      if (updates.category !== undefined) dbUpdates.category = updates.category;

      const { data, error } = await supabase
        .from('products')
        .update(dbUpdates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      setProducts(prev => prev.map(p => p.id === id ? {
        id: data.id,
        name: data.name,
        specs: data.specs,
        color: data.color,
        quantity: data.quantity,
        unitPrice: Number(data.unit_price),
        minStock: data.min_stock,
        category: data.category,
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at),
      } : p));

      toast.success('Product updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating product:', error);
      toast.error('Failed to update product');
      throw error;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setProducts(prev => prev.filter(p => p.id !== id));
      toast.success('Product deleted successfully');
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
      throw error;
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return { products, loading, addProduct, updateProduct, deleteProduct, refetch: fetchProducts };
}
